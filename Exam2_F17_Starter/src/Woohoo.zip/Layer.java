import java.util.ArrayList;

public class Layer {
	private String name;
	private ArrayList<Shape> Shapes;
	// TODO: declare any member variables you need
	// Use only private access variables

	
	// construct an empty layer with the given name
	public Layer(String name){
		this.name = name;
	}
	
	// returns the layer name
	public String getName(){
		return name;
	}
	
	// adds s to this layer
	public void addShape(Shape s){
		Shapes.add(s);
	}
	
	// returns an ArrayList of the Shape
	//   objects in this layer, in any order
	public ArrayList<Shape> getShapes(){
		return Shapes;
	}
	
	// removes all shapes from this layer
	public void clear(){
		Shapes.clear();
	}

}
