import java.util.Random;

public class DiceGame {
	private final int numPlayers;
	private final int numDice;
	private Random randGen;
	
	public DiceGame(int numPlayers, int numDice){
		this.numPlayers = numPlayers;
		this.numDice = numDice;
		randGen = new Random();
	}
	
	/**
	 * @return the sum of the values from the simulated dice roll
	 */
	public int rollDice() {
		int sum = 0;
		for(int dieNum=0; dieNum<numDice; dieNum++){
			sum += randGen.nextInt(6) + 1;
		}
		return sum;
	}
}
