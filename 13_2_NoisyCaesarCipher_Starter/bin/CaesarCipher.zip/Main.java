import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		String in = "This is a string; it has punctuation. The end!!!";

		ArrayList<CaesarCipher> ciphers = new ArrayList<>();
		ciphers.add(new CaesarCipher(3));
		ciphers.add(new NoisyCaesarCipher(3, 0.1));
		ciphers.add(new NoisyCaesarCipher(3, 0.3));
		
		for(CaesarCipher cc : ciphers){
			String out = cc.encrypt(in);
			System.out.println("Encrypted:  " + out);
			System.out.println("Decrypted:  " + cc.decrypt(out));
			System.out.println();
		}
	}

}
