import java.util.Random;

public class NoisyCaesarCipher extends CaesarCipher{
	private Random randGen;
	private double noiseProb; // probability of generating a random character when encrypting
	
	public NoisyCaesarCipher(int shiftAmount, double noiseProb){
	}
}
