import java.util.ArrayList;

public class Demo {
	public static int findMax(ArrayList<Integer> xs){
		int max = 0;
		for(int i=1; i<xs.size(); i++){
			if(xs.get(i) > max){
				max = xs.get(i);
			}
		}
		return max;
	}
}
