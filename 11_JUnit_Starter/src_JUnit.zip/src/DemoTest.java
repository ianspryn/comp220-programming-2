import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;

public class DemoTest {
	@Test public void oneItem(){
		final int item = 10;
		ArrayList<Integer> xs = new ArrayList<Integer>();
		xs.add(item);
		int result = Demo.findMax(xs);
		Assert.assertEquals(result, item);
	}
	
}
